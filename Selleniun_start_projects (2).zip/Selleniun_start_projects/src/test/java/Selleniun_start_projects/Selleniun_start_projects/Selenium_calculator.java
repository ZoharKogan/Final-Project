package Selleniun_start_projects.Selleniun_start_projects;

import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertEquals;
import java.util.concurrent.TimeUnit;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.lang.System;
public class Selenium_calculator {
	
	static WebDriver  browser;
	 
	 @Before
	  public void setup() {
		 
			  System.setProperty("webdriver.gecko.driver","C:\\Users\\zohar\\Downloads\\geckodriver-v0.34.0-win64\\geckodriver.exe");
		      browser = new FirefoxDriver();
		  	  browser.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
			  String url="https://testpages.eviltester.com/styled/apps/calculator.html";
		      browser.get(url);
		
	  }
	 
	 @Test
		public void Tests1() {	
				browser.findElement(By.id("button01")).click();
				browser.findElement(By.id("buttonplus")).click();
				browser.findElement(By.id("button02")).click();
				try {
					  Thread.sleep(1000);
					} catch (InterruptedException e) {
					  Thread.currentThread().interrupt();
					}	
				browser.findElement(By.id("buttonequals")).click();	
				String result= browser.findElement(By.id("calculated-display")).getAttribute("value").toString();
				String Expected= "3";
				assertEquals(Expected,result);
				browser.close();
	 }
	 
	 @Test
		public void Tests1A() {	
				browser.findElement(By.id("button01")).click();
				browser.findElement(By.id("button01")).click();
				browser.findElement(By.id("buttonplus")).click();
				browser.findElement(By.id("button02")).click();
				try {
					  Thread.sleep(1000);
					} catch (InterruptedException e) {
					  Thread.currentThread().interrupt();
					}	
				browser.findElement(By.id("buttonequals")).click();	
				String result= browser.findElement(By.id("calculated-display")).getAttribute("value").toString();
				String Expected= "13";
				assertEquals(Expected,result);
				browser.close();
	 }
				
	 	
	 
	 @Test
		public void Tests2() {	
				browser.findElement(By.id("button02")).click();
				browser.findElement(By.id("buttonminus")).click();
				browser.findElement(By.id("button01")).click();
				try {
					  Thread.sleep(1000);
					} catch (InterruptedException e) {
					  Thread.currentThread().interrupt();
					}	
				browser.findElement(By.id("buttonequals")).click();
				String result= browser.findElement(By.id("calculated-display")).getAttribute("value").toString();
				String Expected= "1";
				assertEquals(Expected,result);
				browser.close();
				
	 	}
	 @Test
		public void Tests2A() {	
				browser.findElement(By.id("button02")).click();
				browser.findElement(By.id("button02")).click();
				browser.findElement(By.id("buttonminus")).click();
				browser.findElement(By.id("button01")).click();
				try {
					  Thread.sleep(1000);
					} catch (InterruptedException e) {
					  Thread.currentThread().interrupt();
					}	
				browser.findElement(By.id("buttonequals")).click();
				String result= browser.findElement(By.id("calculated-display")).getAttribute("value").toString();
				String Expected= "21";
				assertEquals(Expected,result);
				browser.close();
				
	 	}
	 
	 @Test
		public void Test3() {	
				browser.findElement(By.id("button02")).click();
				browser.findElement(By.id("buttonmultiply")).click();
				browser.findElement(By.id("button02")).click();
				try {
					  Thread.sleep(1000);
					} catch (InterruptedException e) {
					  Thread.currentThread().interrupt();
					}	
				browser.findElement(By.id("buttonequals")).click();
				String result= browser.findElement(By.id("calculated-display")).getAttribute("value").toString();
				System.out.println(result);	
				String Expected= "4";
				assertEquals(Expected,result);	
				browser.close();
	 	}
	 @Test
		public void Test3A() {	
				browser.findElement(By.id("button03")).click();
				browser.findElement(By.id("buttonmultiply")).click();
				browser.findElement(By.id("button02")).click();
				try {
					  Thread.sleep(1000);
					} catch (InterruptedException e) {
					  Thread.currentThread().interrupt();
					}	
				browser.findElement(By.id("buttonequals")).click();
				String result= browser.findElement(By.id("calculated-display")).getAttribute("value").toString();
				System.out.println(result);	
				String Expected= "6";
				assertEquals(Expected,result);	
				browser.close();
	 	}
	 
	 @Test
		public void Test4() {	
				browser.findElement(By.id("button06")).click();
				browser.findElement(By.id("buttondivide")).click();
				browser.findElement(By.id("button02")).click();
				try {
					  Thread.sleep(1000);
					} catch (InterruptedException e) {
					  Thread.currentThread().interrupt();
					}
				
				browser.findElement(By.id("buttonequals")).click();
				String result= browser.findElement(By.id("calculated-display")).getAttribute("value").toString();
				String Expected= "3";
				assertEquals(Expected,result);
				browser.close();
				
	 	}
	 
	 @Test
		public void Test4A() {	
				browser.findElement(By.id("button08")).click();
				browser.findElement(By.id("buttondivide")).click();
				browser.findElement(By.id("button02")).click();
				try {
					  Thread.sleep(1000);
					} catch (InterruptedException e) {
					  Thread.currentThread().interrupt();
					}
				
				browser.findElement(By.id("buttonequals")).click();
				String result= browser.findElement(By.id("calculated-display")).getAttribute("value").toString();
				String Expected= "4";
				assertEquals(Expected,result);
				browser.close();
				
	 	}
	 
	 
	 @Test
		public void Test5() {	
				browser.findElement(By.id("button02")).click();
				browser.findElement(By.id("buttonmultiply")).click();
				browser.findElement(By.id("button00")).click();
				try {
					  Thread.sleep(1000);
					} catch (InterruptedException e) {
					  Thread.currentThread().interrupt();
					}	
				browser.findElement(By.id("buttonequals")).click();
				String result= browser.findElement(By.id("calculated-display")).getAttribute("value").toString();
				String Expected= "0";
				assertEquals(Expected,result);
				browser.close();
	 	}
	 
	 @Test
		public void Test6() {	
				browser.findElement(By.id("button07")).click();
				browser.findElement(By.id("buttonplus")).click();
				browser.findElement(By.id("button00")).click();
				try {
					  Thread.sleep(1000);
					} catch (InterruptedException e) {
					  Thread.currentThread().interrupt();
					}	
				browser.findElement(By.id("buttonequals")).click();
				String result= browser.findElement(By.id("calculated-display")).getAttribute("value").toString();
				String Expected= "7";
				assertEquals(Expected,result);
				browser.close();
				
	 	}
	 
	 @Test
		public void Test7() {	
				browser.findElement(By.id("button02")).click();
				browser.findElement(By.id("button02")).click();
				browser.findElement(By.id("buttondivide")).click();
				browser.findElement(By.id("button00")).click();
				try {
					  Thread.sleep(1000);
					} catch (InterruptedException e) {
					  Thread.currentThread().interrupt();
					}
				browser.findElement(By.id("buttonequals")).click();
				String result= browser.findElement(By.id("calculated-display")).getAttribute("value").toString();
				String Expected= "Infinity";
				assertEquals(Expected,result);
				browser.close();
				
	 	}
	 
	 @Test
		public void Test8() {	
				browser.findElement(By.id("button02")).click();
				browser.findElement(By.id("buttonmultiply")).click();
				browser.findElement(By.id("button02")).click();
				browser.findElement(By.id("buttonequals")).click();
				try {
					  Thread.sleep(1000);
					} catch (InterruptedException e) {
					  Thread.currentThread().interrupt();
					}	
				browser.findElement(By.id("buttonequals")).click();
				String result= browser.findElement(By.id("calculated-display")).getAttribute("value").toString();
				System.out.println(result);	
				String Expected= "8";
				assertEquals(Expected,result);	
				browser.close();
	 	}
	 
	 @Test
	 	public void memoryAddTest() {
		 	browser.findElement(By.id("button05")).click();
		 	browser.findElement(By.id("buttonmemoryplus")).click();
	     	browser.findElement(By.id("buttonallclear")).click();
	     	browser.findElement(By.id("buttonmemoryrecall")).click();
	     	try {
				  Thread.sleep(1000);
				} catch (InterruptedException e) {
				  Thread.currentThread().interrupt();
				}	
			String result= browser.findElement(By.id("calculated-display")).getAttribute("value").toString();
			System.out.println(result);	
			String Expected= "5";
			assertEquals(Expected,result);	
			browser.close();
	 	
	 }
	 
	 @Test
	 	public void clearEntryTest() {
		 	browser.findElement(By.id("button05")).click();
		 	browser.findElement(By.id("buttonplus")).click();
			browser.findElement(By.id("button05")).click();
	     	browser.findElement(By.id("buttonclearentry")).click();
	     	browser.findElement(By.id("button06")).click();
	     	
	     	try {
				  Thread.sleep(1000);
				} catch (InterruptedException e) {
				  Thread.currentThread().interrupt();
				}	
	     	browser.findElement(By.id("buttonequals")).click();
			String result= browser.findElement(By.id("calculated-display")).getAttribute("value").toString();
			System.out.println(result);	
			String Expected= "11";
			assertEquals(Expected,result);	
			browser.close();
	 	
	 }
	 
	 @Test
	 public void memorySetTest() {
	     browser.findElement(By.id("button05")).click();
	     browser.findElement(By.id("buttonmemoryin")).click(); 
	     browser.findElement(By.id("buttonallclear")).click(); 
	     browser.findElement(By.id("buttonmemoryrecall")).click(); 
	     try {
	         Thread.sleep(1000);
	     } catch (InterruptedException e) {
	         Thread.currentThread().interrupt();
	     }

	     String result = browser.findElement(By.id("calculated-display")).getAttribute("value").toString(); 
	     String expected = "5"; 
	     assertEquals(expected, result); 
	     browser.close();
	 }
	 
	 @Test
		public void Tests9() {	
				browser.findElement(By.id("button02")).click();
				browser.findElement(By.id("buttonminus")).click();
				browser.findElement(By.id("button04")).click();
				try {
					  Thread.sleep(1000);
					} catch (InterruptedException e) {
					  Thread.currentThread().interrupt();
					}	
				browser.findElement(By.id("buttonequals")).click();
				String result= browser.findElement(By.id("calculated-display")).getAttribute("value").toString();
				String Expected= "-2";
				assertEquals(Expected,result);
				browser.close();
				
	 	}
	 @Test
		public void Tests10() {	
				browser.findElement(By.id("button02")).click();
				browser.findElement(By.id("buttondot")).click();
				browser.findElement(By.id("button05")).click();
				browser.findElement(By.id("buttonminus")).click();
				browser.findElement(By.id("button01")).click();
				browser.findElement(By.id("buttondot")).click();
				browser.findElement(By.id("button02")).click();
				try {
					  Thread.sleep(1000);
					} catch (InterruptedException e) {
					  Thread.currentThread().interrupt();
					}	
				browser.findElement(By.id("buttonequals")).click();
				String result= browser.findElement(By.id("calculated-display")).getAttribute("value").toString();
				String Expected= "1.3";
				assertEquals(Expected,result);
				browser.close();
				
	 	}
	 
	 
	 }