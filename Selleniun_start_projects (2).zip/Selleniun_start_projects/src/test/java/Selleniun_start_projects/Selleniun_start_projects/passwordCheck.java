package Selleniun_start_projects.Selleniun_start_projects;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.util.concurrent.TimeUnit;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class passwordCheck {
static WebDriver  browser;
	
	@Before
	  public void setup() {
		 
			  System.setProperty("webdriver.gecko.driver","C:\\Users\\zohar\\Downloads\\geckodriver-v0.34.0-win64\\geckodriver.exe");
		      browser = new FirefoxDriver();
		  	  browser.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
			  String url="https://testpages.eviltester.com/styled/apps/7charval/simple7charvalidation.html";
		      browser.get(url);	
	  }
	
	@Test
	public void CorrectPassword() {
		WebElement textBox = browser.findElement(By.name("characters"));
		textBox.sendKeys("chaya12");
		browser.findElement(By.name("validate")).click();  
		WebElement answer = browser.findElement(By.name("validation_message"));
		String value = answer.getAttribute("value");
		String Expected = "Valid Value";
		assertEquals(value, Expected);
		browser.close();
		
	}
	@Test
	public void inCorrectPassword() {
		WebElement textBox = browser.findElement(By.name("characters"));
		textBox.sendKeys("cha12!!");
		browser.findElement(By.name("validate")).click();  
		WebElement answer = browser.findElement(By.name("validation_message"));
		String value = answer.getAttribute("value");
		String Expected = "Invalid Value";
		assertEquals(value, Expected);
		browser.close();
		
	}
	@Test
	public void inCorrectPassword2() {
		WebElement textBox = browser.findElement(By.name("characters"));
		textBox.sendKeys("cha12??");
		browser.findElement(By.name("validate")).click();  
		WebElement answer = browser.findElement(By.name("validation_message"));
		String value = answer.getAttribute("value");
		String Expected = "Invalid Value";
		assertEquals(value, Expected);
		browser.close();
		
	}
	
	@Test
	public void inCorrectPassword3() {
		WebElement textBox = browser.findElement(By.name("characters"));
		textBox.sendKeys("cha12&&");
		browser.findElement(By.name("validate")).click();  
		WebElement answer = browser.findElement(By.name("validation_message"));
		String value = answer.getAttribute("value");
		String Expected = "Invalid Value";
		assertEquals(value, Expected);
		browser.close();
		
	}
	@Test
	public void inCorrectPassword4() {
		WebElement textBox = browser.findElement(By.name("characters"));
		textBox.sendKeys("cha1$$2");
		browser.findElement(By.name("validate")).click();  
		WebElement answer = browser.findElement(By.name("validation_message"));
		String value = answer.getAttribute("value");
		String Expected = "Invalid Value";
		assertEquals(value, Expected);
		browser.close();
	}
	
	@Test
	public void LongPassword() {
		WebElement textBox = browser.findElement(By.name("characters"));
		textBox.sendKeys("cha12345678");
		browser.findElement(By.name("validate")).click();  
		WebElement answer = browser.findElement(By.name("validation_message"));
		String value = answer.getAttribute("value");
		String Expected = "Invalid Value";
		assertEquals(value, Expected);
		browser.close();
	}
	
	@Test
	public void ShortPassword() {
		WebElement textBox = browser.findElement(By.name("characters"));
		textBox.sendKeys("cha12");
		browser.findElement(By.name("validate")).click();  
		WebElement answer = browser.findElement(By.name("validation_message"));
		String value = answer.getAttribute("value");
		String Expected = "Invalid Value";
		assertEquals(value, Expected);
		browser.close();
		
	}
	
	@Test
	public void inCorreectData() {
		WebElement textBox = browser.findElement(By.name("characters"));
		textBox.sendKeys("123^eed");
		browser.findElement(By.name("validate")).click();  
		WebElement answer = browser.findElement(By.name("validation_message"));
		String value = answer.getAttribute("value");
		String Expected = "Invalid Value";
		assertEquals(value, Expected);
		browser.close();
		
	}
	
	@Test
	public void inCorreectData2() {
		WebElement textBox = browser.findElement(By.name("characters"));
		textBox.sendKeys("12345678");
		browser.findElement(By.name("validate")).click();  
		WebElement answer = browser.findElement(By.name("validation_message"));
		String value = answer.getAttribute("value");
		String Expected = "Invalid Value";
		assertEquals(value, Expected);
		browser.close();
	}
	
	@Test
	public void inCorreectData3() {
		WebElement textBox = browser.findElement(By.name("characters"));
		textBox.sendKeys("12345_6");
		browser.findElement(By.name("validate")).click();  
		WebElement answer = browser.findElement(By.name("validation_message"));
		String value = answer.getAttribute("value");
		String Expected = "Invalid Value";
		assertEquals(value, Expected);
		browser.close();
	}
	
}


