package Selleniun_start_projects.Selleniun_start_projects;

import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertEquals;
import java.util.concurrent.TimeUnit;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.lang.System;

public class ClassisicationCheck {
	
	static WebDriver  browser;
	
	@Before
	public void setup() {
			  System.setProperty("webdriver.gecko.driver","C:\\Users\\zohar\\Downloads\\geckodriver-v0.34.0-win64\\geckodriver.exe");
		      browser = new FirefoxDriver();
		  	  browser.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
			  String url="https://testpages.eviltester.com/styled/apps/triangle/triangle001.html";
		      browser.get(url);	
	  }
	@Test
	public void TS1() {
		browser.findElement(By.name("side1")).sendKeys("1");
		browser.findElement(By.name("side2")).sendKeys("4");
		browser.findElement(By.name("side3")).sendKeys("6");
		String exceptedValue = "Error: Not a Triangle";
		browser.findElement(By.id("identify-triangle-action")).click();
		String result = browser.findElement(By.id("triangle-type")).toString();
		assertNotEquals(result, exceptedValue);
		browser.close();		
	}
	@Test
	public void TS2() {
		browser.findElement(By.name("side1")).sendKeys("5");
		browser.findElement(By.name("side2")).sendKeys("2");
		browser.findElement(By.name("side3")).sendKeys("2");
		String exceptedValue = "Error: Not a Triangle";
		browser.findElement(By.id("identify-triangle-action")).click();
		String result = browser.findElement(By.id("triangle-type")).toString();
		assertNotEquals(result, exceptedValue);
		browser.close();		
	}
	@Test
	public void TS3() {
		browser.findElement(By.name("side1")).sendKeys("2");
		browser.findElement(By.name("side2")).sendKeys("5");
		browser.findElement(By.name("side3")).sendKeys("2");
		String exceptedValue = "Error: Not a Triangle";
		browser.findElement(By.id("identify-triangle-action")).click();
		String result = browser.findElement(By.id("triangle-type")).toString();
		assertNotEquals(result, exceptedValue);
		browser.close();		
	}
	@Test
	public void TS4() {
		browser.findElement(By.name("side1")).sendKeys("2");
		browser.findElement(By.name("side2")).sendKeys("2");
		browser.findElement(By.name("side3")).sendKeys("5");
		String exceptedValue = "Error: Not a Triangle";
		browser.findElement(By.id("identify-triangle-action")).click();
		String result = browser.findElement(By.id("triangle-type")).toString();
		assertNotEquals(result, exceptedValue);
		browser.close();		
	}
	@Test
	public void TS5() {
		browser.findElement(By.name("side1")).sendKeys("2");
		browser.findElement(By.name("side2")).sendKeys("3");
		browser.findElement(By.name("side3")).sendKeys("4");
		String exceptedValue = "Scalene";
		browser.findElement(By.id("identify-triangle-action")).click();
		String result = browser.findElement(By.id("triangle-type")).toString();
		assertNotEquals(result, exceptedValue);
		browser.close();		
	}
	
	@Test
	public void TS6() {
		browser.findElement(By.name("side1")).sendKeys("3");
		browser.findElement(By.name("side2")).sendKeys("2");
		browser.findElement(By.name("side3")).sendKeys("2");
		String exceptedValue = "Isosceles";
		browser.findElement(By.id("identify-triangle-action")).click();
		String result = browser.findElement(By.id("triangle-type")).toString();
		assertNotEquals(result, exceptedValue);
		browser.close();		
	}
	@Test
	public void TS7() {
		browser.findElement(By.name("side1")).sendKeys("2");
		browser.findElement(By.name("side2")).sendKeys("3");
		browser.findElement(By.name("side3")).sendKeys("2");
		String exceptedValue = "Isosceles";
		browser.findElement(By.id("identify-triangle-action")).click();
		String result = browser.findElement(By.id("triangle-type")).toString();
		assertNotEquals(result, exceptedValue);
		browser.close();		
	}
	@Test
	public void TS8() {
		browser.findElement(By.name("side1")).sendKeys("2");
		browser.findElement(By.name("side2")).sendKeys("2");
		browser.findElement(By.name("side3")).sendKeys("3");
		String exceptedValue = "Isosceles";
		browser.findElement(By.id("identify-triangle-action")).click();
		String result = browser.findElement(By.id("triangle-type")).toString();
		assertNotEquals(result, exceptedValue);
		browser.close();		
	}
	
	@Test
	public void TC9() {
		browser.findElement(By.name("side1")).sendKeys("3");
		browser.findElement(By.name("side2")).sendKeys("3");
		browser.findElement(By.name("side3")).sendKeys("3");
		String exceptedValue = "Equilateral";
		browser.findElement(By.id("identify-triangle-action")).click();
		String result = browser.findElement(By.id("triangle-type")).toString();
		assertNotEquals(result, exceptedValue);
		browser.close();		
	}
	
	@Test
	public void Error1Check() {
		browser.findElement(By.name("side1")).sendKeys("");
		browser.findElement(By.name("side2")).sendKeys("5");
		browser.findElement(By.name("side3")).sendKeys("4");
		String exceptedValue = "Error: Side 1 is missing";
		browser.findElement(By.id("identify-triangle-action")).click();
		String result = browser.findElement(By.id("triangle-type")).toString();
		assertNotEquals(result, exceptedValue);
		browser.close();		
	}
	
	@Test
	public void Error2Check() {
		browser.findElement(By.name("side1")).sendKeys("4");
		browser.findElement(By.name("side2")).sendKeys("");
		browser.findElement(By.name("side3")).sendKeys("4");
		String exceptedValue = "Error: Side 2 is missing";
		browser.findElement(By.id("identify-triangle-action")).click();
		String result = browser.findElement(By.id("triangle-type")).toString();
		assertNotEquals(result, exceptedValue);
		browser.close();		
	}
	
	@Test
	public void Error3Check() {
		browser.findElement(By.name("side1")).sendKeys("5");
		browser.findElement(By.name("side2")).sendKeys("4");
		browser.findElement(By.name("side3")).sendKeys("");
		String exceptedValue = "Error: Side 3 is missing";
		browser.findElement(By.id("identify-triangle-action")).click();
		String result = browser.findElement(By.id("triangle-type")).toString();
		assertNotEquals(result, exceptedValue);
		browser.close();		
	}
	
	
	
	
}